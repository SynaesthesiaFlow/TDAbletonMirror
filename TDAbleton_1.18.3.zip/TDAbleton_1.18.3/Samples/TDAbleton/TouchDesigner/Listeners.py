# Listeners.py

from OSC import OSCMessage
import Live

SPECIALLISTENERS = ['*BeatTime', '*MIDINotes']
# region Init

class Listeners:
	"""
	Watch Registry tracks and optimizes Live object watch requests
	"""

	def __init__(self, client):
		self.client = client
		self.codeContext = client.context
		self.registry = {} # (lomExpression, property, returnAddress):
							# {'registrants': set(requesterID),
							#	'callback': callback,
							#	'setterIndex': setterIndex,
							# 	'liveObject': lomExpression result
							# }
		self.setters = []
		self.debug = self.codeContext['TDA'].debug

	@property
	def debugging(self):
		return self.codeContext['TDA'].debugging

	def add(self, lomExpression, property, returnAddress, id, extra=''):
		"""
		Add an item to the registry
		Set up listener callback
		:param lomExpression: Python expression to reach Live object, e.g.:
									'SONG.tracks[1].devices[3].parameters[2]'
		:param property: property of object that has watcher, e.g.: 'Value'
		:param returnAddress: OSC address to send updates to. "" = no return
		:param id: unique ID of watcher
		:param extra: an extra string with instructions.
				'noinit' = don't send initial value message
		"""

		# trying to make this as fast as possible because it will probably get
		# called many times per frame
		registryKey = (lomExpression, property, returnAddress)
		if registryKey in self.registry:
			# self.debug('reg', lomExpression, property, returnAddress) # debug
			self.registry[registryKey]['registrants'].add(id)
			setterIndex = self.registry[registryKey]['setterIndex']
		else:
			# self.debug('add', lomExpression, property, returnAddress) # debug
			if lomExpression in SPECIALLISTENERS:
				self.registry[registryKey] = \
									self.addSpecial(lomExpression, property,
											 				returnAddress, id)
				setterIndex = self.registry[registryKey]['setterIndex']
			else:
				context = dict(locals())
				context.update(self.codeContext)
				context['OSCMessage'] = OSCMessage
				liveObject = eval(lomExpression, context)
				callbackCode = \
				"""def watchCallback():
						self.client.send(OSCMessage('""" + returnAddress + \
							"'," + lomExpression + "." + property + "))"
				addCode = lomExpression + ".add_" + property + \
												'_listener(watchCallback)'
				fullCode = '\n'.join([callbackCode, addCode])
				try:
					exec(fullCode, context)
				except:
					self.codeContext['TDA'].sendError(
							'Error creating listener from OP id: ' + str(id),
							self.client)
					raise
				watchCallback = context['watchCallback']
				# create setter
				try:
					setterIndex = self.setters.index('')
				except ValueError:
					setterIndex = len(self.setters)
					self.setters.append('')
				propVal = getattr(liveObject, property)
				# convert val only if non-float
				if type(propVal) != float:
					valCode = type(propVal).__name__ + '(val)'
				else:
					valCode = 'val'
				setterCode = \
				"""def setter(val):
						""" + lomExpression + '.' + property + ' = ' + valCode
				fullCode = '\n'.join([setterCode,
									  "self.setters[setterIndex] = setter"])
				locals().update(self.codeContext)
				exec(fullCode, locals())
				# self.debug('add', registryKey)
				self.registry[registryKey] = {'registrants':{id},
											  'callback': watchCallback,
											  'setterIndex': setterIndex,
											  'liveObject': liveObject}
		if setterIndex is not None:
			self.client.send(OSCMessage(
						'/listener' + registryKey[2] + '/setterIndex',
								[setterIndex,
								 lomExpression, property, returnAddress, id]))

		if 'noinit' not in extra:
			self.registry[registryKey]['callback']()

	def remove(self, lomExpression, property, returnAddress, id=None, extra=''):
		"""
		Remove an item from the registry, stop callbacks if there are no
			remaining ids waiting for it.
		:param lomExpression: Python expression to reach Live object, e.g.:
									'SONG.tracks[1].devices[3].parameters[2]'
		:param property: property of object that has watcher, e.g.: 'Value'
		:param returnAddress: OSC address to send updates to
		:param id: unique ID of watcher. If None, remove listener.
		:param extra: an extra string with instructions.
				'noinit' = don't send initial value message
		"""
		registryKey = (lomExpression, property, returnAddress)
		# remove listener
		# self.debug('remove', lomExpression, property, returnAddress)  # debug
		if registryKey not in self.registry:
			# self.debug('NOTINREG', lomExpression, property, returnAddress)
			return
		registryInfo = self.registry[registryKey]
		if id is None:
			registeredIDs = []
		else:
			registeredIDs = registryInfo['registrants']
			if id in registeredIDs:
				registeredIDs.remove(id)
		if not registeredIDs:
			if lomExpression in SPECIALLISTENERS:
				self.removeSpecial(lomExpression, property, returnAddress, id,
								   							extra, registryInfo)
			# remove listener
			# self.debug('DO REMOVE', lomExpression, property, returnAddress) # debug
			try:
				getattr(registryInfo['liveObject'],
							"remove_" + property + "_listener")\
													(registryInfo['callback'])
			except:
				# import traceback; self.debug(traceback.format_exc()) #debug
				pass
			# clear setter
			if registryInfo['setterIndex'] is not None:
				self.setters[registryInfo['setterIndex']] = ''
			del self.registry[registryKey]
		# self.debug('remove', registryKey)

	def disconnect(self):
		"""
		Remove all listeners
		"""
		for key in list(self.registry.keys()):
			self.remove(key[0], key[1], key[2])

	def set(self, setterIndex, value):
		"""
		Set a listened-to value
		:param setterIndex: index of setter
		:param value: value to set to
		:return:
		"""
		# self.debug(setterIndex, value)
		# self.debug(self.setters)
		try:
			self.setters[setterIndex](value)
		except:
			for key, info in self.registry.items():
				if info['setterIndex'] == setterIndex:
					raise Exception('Error setting ' + key[0] + ' property: ' +
									key[1], 'returnAddress:' + key[2])
			return # deleted setter

	def addSpecial(self, lomExpression, property, returnAddress, id, extra=''):
		"""
		Set up whatever is needed for special .
		:param lomExpression: Special ID. Starts with '*'
		:param property: Any relevant info
		:param returnAddress: OSC address to send updates to
		:param id: unique ID of watcher
		:returns registry info
		"""
		addFunction = getattr(self, 'add' + lomExpression[1:], None)
		setterIndex = None
		liveObject = None
		addInfo = addFunction(property, returnAddress, extra)
		setterIndex = addInfo.get('setterIndex')
		liveObject = addInfo.get('liveObject')
		callback = addInfo['callback']
		return {'registrants': {id},
				'callback': callback,
				'setterIndex': setterIndex,
				'liveObject': liveObject}

	def removeSpecial(self, lomExpression, property, returnAddress, id, extra,
					  										registryInfo):
		"""
		Remove a special item from the registry, stop callbacks if there are no
			remaining ids waiting for it.
		:param lomExpression: Special ID. Starts with '*'
		:param property: Any relevant info
		:param returnAddress: OSC address to send updates to
		:param id: unique ID of watcher
		"""
		removeFunction = getattr(self, 'remove' + lomExpression[1:], None)
		if removeFunction:
			removeFunction(property, returnAddress, extra, registryInfo)

	# region Beat Time

	def addBeatTime(self, property, returnAddress, extra=''):
		context = dict(self.codeContext)
		context['OSCMessage'] = OSCMessage
		context['self'] = self
		callbackCode = \
		"def callbackBeatTime():\n" \
		"	time = SONG.get_current_beats_song_time()\n" \
		"	self.client.send(OSCMessage('" + returnAddress + "/bars', "\
													"[time.bars]))\n"\
		"	self.client.send(OSCMessage('" + returnAddress + "/beats', "\
													"[time.beats]))\n"\
		"	self.client.send(OSCMessage('" + returnAddress + "/sixteenths', "\
													"[time.sub_division]))\n"\
		"	self.client.send(OSCMessage('" + returnAddress + "/time', "\
												"[SONG.current_song_time]))\n"
		exec(callbackCode, context)
		callback = context['callbackBeatTime']
		self.codeContext['SONG'].add_current_song_time_listener(callback)
		return {'callback': callback }

	def removeBeatTime(self, property, returnAddress, extra, registryInfo):
		self.codeContext['SONG'].remove_current_song_time_listener(
												registryInfo['callback'])

	# endregion

	# region MIDI notes

	def addMIDINotes(self, property, returnAddress, extra=''):
		context = dict(self.codeContext)
		context['OSCMessage'] = OSCMessage
		context['self'] = self
		clip = eval(property[:property.find('get_notes')-1], context)
		callbackCode = \
		"def callbackMIDINotes():\n" \
		"	notes = " + property + "\n" \
		"	self.client.send(OSCMessage('" + returnAddress + "', "\
													"[notes]))\n"
		exec(callbackCode, context)
		callback = context['callbackMIDINotes']
		clip.add_notes_listener(callback)
		return {'callback': callback }

	def removeMIDINotes(self, property, returnAddress, extra, registryInfo):
		clip = eval(property[:property.find('get_notes')-1],
													dict(self.codeContext))
		clip.remove_notes_listener(registryInfo['callback'])


	# endregion


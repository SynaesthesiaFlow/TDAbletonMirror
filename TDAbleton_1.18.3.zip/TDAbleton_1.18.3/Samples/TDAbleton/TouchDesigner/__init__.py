#__init__.py
from TDA import TDA

def create_instance(c_instance):
	return TDA(c_instance)